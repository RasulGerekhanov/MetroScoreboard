﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tablo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Interval = 100;
            timer1.Start();
            timer2.Interval = 100;
            timer2.Start();
            stancii();
        }

        //public static vrem(string time)
        //{
        //    int hour = time. ;
        //}
        public static int vrema(string hour, string min, int Min)
        {
            int h;
            int m;
            m = int.Parse(min);
            int chas;
            h = int.Parse(hour);
            chas = h * 60 + m + Min;
            return chas;
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
        string t1 = "";
        string t2 = "";
        string t3 = "";
        string t4 = "";
        string t5 = "";
        string t6 = "";
        string t7 = "";
        string t_1 = "";
        string t_2 = "";
        string t_3 = "";
        string t_4 = "";
        string t_5 = "";
        string t_6 = "";
        string t_7 = "";
        int t11 = 60;
        int t22 = 75;
        int t33 = 30;
        int t44 = 80;
        int t55 = 45;
        int t66 = 15;
        int t77 = 24;
        int T1;
        int T2;
        int T3;
        int T4;
        int T5;
        int T6;
        int T7;
        private void Timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToShortDateString() + "  " + DateTime.Now.ToLongTimeString();

            timer1.Start();
         
        }
        
        public void stancii()
        {
            label6.Text = "ВДНХ";
            label7.Text = "Кремль";
            label8.Text = "Сокольники";
            label9.Text = "Лужники";
            label10.Text = "Москва Сити";
            label11.Text = "Китай город";
            label12.Text = "Домодедово";
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            
                label5.Text = "Такси Везет 89666677777";
                timer2.Stop();
                timer3.Interval = 5000;
                timer3.Start();
        }

        private void Timer3_Tick(object sender, EventArgs e)
        {
            label5.Text = "Uber 8966666666";
            timer3.Stop();
            timer4.Interval = 5000;
            timer4.Start();
        }

        private void Timer4_Tick(object sender, EventArgs e)
        {
            label5.Text = "Экскурсии по городу 25552352";
            timer4.Stop();
            timer5.Interval = 5000;
            timer5.Start();
        }

        private void Timer5_Tick(object sender, EventArgs e)
        {
            label5.Text = "Лучший интернет провайдер YOTA";
            timer5.Stop();
            timer2.Interval = 5000;
            timer2.Start();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            button3.Visible = true;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Visible = false;
                textBox2.Visible = false;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = false;
                textBox6.Visible = false;
                textBox7.Visible = false;
                button3.Visible = false;
                textBox8.Visible = false;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
                textBox14.Visible = false;
                t1 = textBox1.Text;
                t2 = textBox2.Text;
                t3 = textBox3.Text;
                t4 = textBox4.Text;
                t5 = textBox5.Text;
                t6 = textBox6.Text;
                t7 = textBox7.Text;
                t_1 = textBox8.Text;
                t_2 = textBox9.Text;
                t_3 = textBox10.Text;
                t_4 = textBox11.Text;
                t_5 = textBox12.Text;
                t_6 = textBox13.Text;
                t_7 = textBox14.Text;
                label14.Text = t1 + ":" + t_1;
                label15.Text = t2 + ":" + t_2;
                label16.Text = t3 + ":" + t_3;
                label17.Text = t4 + ":" + t_4;
                label18.Text = t5 + ":" + t_5;
                label19.Text = t6 + ":" + t_6;
                label20.Text = t7 + ":" + t_7;
                int c = vrema(t1, t_1, t11);
                int d = vrema(t1, t_1, t11);
                label21.Text = Convert.ToString(c / 60 + ":" + c % 60);
                c = vrema(t2, t_2, t22);
                d = vrema(t2, t_2, t22);
                label22.Text = Convert.ToString(c / 60 + ":" + c % 60);
                c = vrema(t3, t_3, t33);
                d = vrema(t3, t_3, t33);
                label23.Text = Convert.ToString(c / 60 + ":" + c % 60);
                c = vrema(t4, t_4, t44);
                d = vrema(t4, t_4, t44);
                label24.Text = Convert.ToString(c / 60 + ":" + c % 60);
                c = vrema(t5, t_5, t55);
                d = vrema(t5, t_5, t55);
                label25.Text = Convert.ToString(c / 60 + ":" + c % 60);
                c = vrema(t6, t_6, t66);
                d = vrema(t6, t_6, t66);
                label26.Text = Convert.ToString(c / 60 + ":" + c % 60);
                c = vrema(t7, t_7, t77);
                d = vrema(t7, t_7, t77);
                label27.Text = Convert.ToString(c / 60 + ":" + c % 60);
            }
            catch
            {
                //MessageBox.Show("Введите корректное число");
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = true;
                textBox12.Visible = true;
                textBox13.Visible = true;
                textBox14.Visible = true;
                button3.Visible = true;
                label14.Text =  "Ошибка";
                label15.Text = "Ошибка";
                label16.Text = "Ошибка";
                label17.Text = "Ошибка";
                label18.Text = "Ошибка";
                label19.Text = "Ошибка";
                label20.Text = "Ошибка";
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox13.Text = "";
                textBox14.Text = "";

            }
           
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        //private void Button2_Click(object sender, EventArgs e)
        //{
        //    //textBox15.Visible = true;
        //    //button4.Visible = true;
        //}
        //int u;
        //private void Button4_Click(object sender, EventArgs e)
        //{
        //u = int.Parse(textBox15.Text);
        //if(u==10)
        //{
        //    t1 = t2=t3=t4=t5=t6=t7="10";
        //    t_1 = t_2 = t_3 = t_4 = t_5 = t_6 = t_7 = "15";
        //    t1 = textBox1.Text;
        //    t2 = textBox2.Text;
        //    t3 = textBox3.Text;
        //    t4 = textBox4.Text;
        //    t5 = textBox5.Text;
        //    t6 = textBox6.Text;
        //    t7 = textBox7.Text;
        //    t_1 = textBox8.Text;
        //    t_2 = textBox9.Text;
        //    t_3 = textBox10.Text;
        //    t_4 = textBox11.Text;
        //    t_5 = textBox12.Text;
        //    t_6 = textBox13.Text;
        //    t_7 = textBox14.Text;
        //    int c = vrema(t1, t_1, t11);
        //    int d = vrema(t1, t_1, t11);
        //    label21.Text = Convert.ToString(c / 60 + ":" + c % 60);
        //    c = vrema(t2, t_2, t22);
        //    d = vrema(t2, t_2, t22);
        //    label22.Text = Convert.ToString(c / 60 + ":" + c % 60);
        //    c = vrema(t3, t_3, t33);
        //    d = vrema(t3, t_3, t33);
        //    label23.Text = Convert.ToString(c / 60 + ":" + c % 60);
        //    c = vrema(t4, t_4, t44);
        //    d = vrema(t4, t_4, t44);
        //    label24.Text = Convert.ToString(c / 60 + ":" + c % 60);
        //    c = vrema(t5, t_5, t55);
        //    d = vrema(t5, t_5, t55);
        //    label25.Text = Convert.ToString(c / 60 + ":" + c % 60);
        //    c = vrema(t6, t_6, t66);
        //    d = vrema(t6, t_6, t66);
        //    label26.Text = Convert.ToString(c / 60 + ":" + c % 60);
        //    c = vrema(t7, t_7, t77);
        //    d = vrema(t7, t_7, t77);
        //    label27.Text = Convert.ToString(c / 60 + ":" + c % 60);
        //}
        //}

        //private void TextBox15_TextChanged(object sender, EventArgs e)
        //{

        //}

        //private void Button4_Click_1(object sender, EventArgs e)
        //{

        //}
    }
}
